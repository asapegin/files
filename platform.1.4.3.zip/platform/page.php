<?php 
/*
	This theme is Copyright (C) 2008-2010 Andrew Powers, PageLines.com (andrew AT pagelines DOT com)
*/

setup_pagelines_template();
	
