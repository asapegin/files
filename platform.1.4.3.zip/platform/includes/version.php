<?php 

// Internal build versions.


$platform_build = '18';