<?php
/*
	
	THEME INITIALIZATION
	
	This file loads the core framework for Platform which handles everything. 
	
	This theme copyright (C) 2008-2010 PageLines

*/

require_once(TEMPLATEPATH . "/includes/core.init.php");
