<?php 
/*
	This theme is Copyright (C) 2008-2010 Andrew Powers, PageLines.com (andrew AT pagelines DOT com)

	Licensed under the terms of GPL.

*/

setup_pagelines_template();
	